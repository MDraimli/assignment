* The index file contains index.html which was Task1 

* The file assets/js/script.js contains task 2 and 3 and also linked to the index.html file so you can check the log if you want

* The File assets/ts/product.ts contains Task 4 and 5 and after to compile it use the following command assets/ts/product.ts --outDir assets/js

* the compiled version of the assets/ts/product.ts is assets/js/product.js which is linked to the index file so the result shows in the log.


** on The Root there is image.png which has screenshot of my tasks**


* Thank you for reading*